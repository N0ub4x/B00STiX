B00STiX.bat:
Keep watching the PC if your PC have an screen saver.

First Release: 1.0
Latest Release: 1.3
--------------------
Removed one command and some change